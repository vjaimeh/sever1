<?php
// Heading 
$_['heading_title']    = 'Afiliado';

// Text
$_['text_register']    = 'Registro';
$_['text_login']       = 'Conectar';
$_['text_logout']      = 'Desconectar';
$_['text_forgotten']   = 'Clave Olvidada';
$_['text_account']     = 'Mi Cuenta';
$_['text_edit']        = 'Editar Cuenta';
$_['text_password']    = 'Clave';
$_['text_payment']     = 'Opciones Pago';
$_['text_tracking']    = 'Seguimiento Afiliado';
$_['text_transaction'] = 'Transacciones';
?>
