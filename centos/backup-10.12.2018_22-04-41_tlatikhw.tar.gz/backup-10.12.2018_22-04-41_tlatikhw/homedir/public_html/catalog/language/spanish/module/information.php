<?php
// Heading 
$_['heading_title'] = 'Información';

// Text
$_['text_contact']  = 'Contáctenos';
$_['text_sitemap']  = 'Mapa del Sitio';
?>