<?php
// Text
$_['text_friend']       = 'Cuéntele a un Amigo';
$_['text_information']  = 'Información';
$_['text_service']      = 'Servicio al Cliente';
$_['text_extra']        = 'Extras';
$_['text_account']      = 'Cuenta';
$_['text_contact']      = 'Contáctenos';
$_['text_return']       = 'Devoluciones';
$_['text_sitemap']      = 'Mapa del Sitio';
$_['text_manufacturer'] = 'Marcas';
$_['text_voucher']      = 'Certificados de Regalos';
$_['text_affiliate']    = 'Afiliados';
$_['text_special']      = 'Ofertas';
$_['text_account']      = 'Mi Cuenta';
$_['text_order']        = 'Historial de Pedidos';
$_['text_wishlist']     = 'Lista de Deseos';
$_['text_newsletter']   = 'Boletín de Noticias';
$_['text_powered']      = 'Diseñado por <a href="http://www.fpress.com">FPress OpenCart Store</a><br /> %s &copy; %s';
?>