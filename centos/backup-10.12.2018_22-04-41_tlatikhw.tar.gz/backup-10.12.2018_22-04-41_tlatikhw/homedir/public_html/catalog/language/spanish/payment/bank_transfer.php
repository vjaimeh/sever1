<?php
// Text
$_['text_title']       = 'Transferencia Bancaria';
$_['text_instruction'] = 'Instrucciones de Transferencias Bancarias';
$_['text_description'] = 'Por Favor Transfiera el Monto Total a la siguiente Cuenta de Banco.';
$_['text_payment']     = 'Su Orden NO será Enviada hasta que su PAGO SEA RECIBIDO.';
?>