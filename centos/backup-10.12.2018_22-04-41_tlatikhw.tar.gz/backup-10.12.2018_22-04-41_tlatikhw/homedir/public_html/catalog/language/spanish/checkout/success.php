<?php
// Heading
$_['heading_title'] = 'Su Pedido ha sido Procesado!';

// Text
$_['text_customer'] = '<p>Su Pedido ha sido satisfactoriamente procesado</p><p>Puede Consultar su Historial de Pedidos en la Página <a href="%s">Mi Cuenta</a> y hacer Click en <a href="%s">Historial</a>.</p>Si su Compra tiene una Descarga asociada, puede ir a al enlace <a href="%s">Descargas</a> para verlas.<p></p><p>Por favor dirija cualquier pregunta que tenga a nuestro <a href="%s">Servicio al Cliente</a>.</p><p>GRACIAS por su Compra en Nuestra Tienda en Línea!</p>';
$_['text_guest']    = '<p>Su Pedido se ha procesado con exito!</p><p>Por favor dirija cualquier duda que tenga a <a href="%s">dueño de la tienda</a>.</p><p>Gracias por comprar on-line con nosotros!</p>';
$_['text_basket']   = 'Carro de Compras';
$_['text_checkout'] = 'Pagar';
$_['text_success']  = 'Correcto';
?>