<?php
// Text
$_['text_title']  = 'Envío basado en el Peso';
$_['text_weight'] = 'Peso:'; 
?>