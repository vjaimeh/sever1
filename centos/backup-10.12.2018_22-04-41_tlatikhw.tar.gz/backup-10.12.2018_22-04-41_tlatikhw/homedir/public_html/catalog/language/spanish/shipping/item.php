<?php
// Text
$_['text_title']       = 'Por Artículo';
$_['text_description'] = 'Tarifa de Envío por Artículo';
?>