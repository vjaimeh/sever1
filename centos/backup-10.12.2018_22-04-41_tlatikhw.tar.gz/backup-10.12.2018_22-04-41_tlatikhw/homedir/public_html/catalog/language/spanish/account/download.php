<?php
// Heading 
$_['heading_title']   = 'Descargas';

// Text
$_['text_account']    = 'Cuenta';
$_['text_downloads']  = 'Descargas';
$_['text_order']      = 'ID Orden:';
$_['text_date_added'] = 'Fecha Adicionada:';
$_['text_name']       = 'Nombre:';
$_['text_remaining']  = 'Restantes:';
$_['text_size']       = 'Tamaño:';
$_['text_empty']      = 'Usted no ha hecho ninguna Orden Descargable previamente!';
?>