<?php
// Text
$_['text_coupon'] = 'Cupon(%s)';
?>