<?php
// Text
$_['text_title']       = 'Envío Gratuíto';
$_['text_description'] = 'Envío Gratuito';
?>