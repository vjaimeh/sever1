<?php
$_['title']         = 'OpenBay Pro stock link report';
$_['help']          = 'Click here for support';