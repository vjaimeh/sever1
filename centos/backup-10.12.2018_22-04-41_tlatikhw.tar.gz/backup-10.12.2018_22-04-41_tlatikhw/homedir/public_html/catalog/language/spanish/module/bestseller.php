<?php
// Heading 
$_['heading_title'] = 'Más Vendidos';

// Text
$_['text_reviews']  = 'Basado en %s comentarios.'; 
?>