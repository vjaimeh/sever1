<?php
// Heading 
$_['heading_title']        = 'Carro de la Compra';

// Text
$_['text_items']           = '%s item(s) - %s';
$_['text_empty']           = 'Tu carro esta vacio!';
$_['text_cart']            = 'Ver Carro';
$_['text_checkout']        = 'Checkout';
$_['text_payment_profile'] = 'Suscripciones';
?>