<?php
// Text
$_['text_title'] = 'Tarjeta Cr�dito o D�bito (2Checkout)';
?>