<?php
// Text
$_['text_title']       = 'Tarifa Fija';
$_['text_description'] = 'Tarifa Fija de Envío';
?>