<?php
$_['text_handling'] = 'Tarifa por Manipulación';
?>