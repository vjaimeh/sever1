<?php
// Text
$_['text_title'] = 'Pago Contra Entrega';
?>