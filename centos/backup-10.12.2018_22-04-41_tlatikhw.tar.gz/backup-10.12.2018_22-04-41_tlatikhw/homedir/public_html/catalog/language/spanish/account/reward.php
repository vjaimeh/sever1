<?php
// Heading 
$_['heading_title']      = 'Sus Puntos de Premio';

// Column
$_['column_date_added']  = 'Fecha Adicionada';
$_['column_description'] = 'Descripción';
$_['column_points']      = 'Puntos';

// Text
$_['text_account']       = 'Cuenta';
$_['text_reward']        = 'Puntos de Premio';
$_['text_total']         = 'Su número total de Puntos de Premio es:';
$_['text_empty']         = 'Usted no tiene Puntos de Premios!';
?>