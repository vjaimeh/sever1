<?php
// Text
$_['text_subject']  = 'Usted ha enviado un Certificado de Regalos desde %s';
$_['text_greeting'] = 'Felicidades, Usted ha recibido un Certificado de Regalos por valor de %s';
$_['text_from']     = 'Este Certificado ha sido enviato por %s';
$_['text_message']  = 'Con un Mensaje que dice';
$_['text_redeem']   = 'Para canjear este Certificado, escriba el código el cual es <b>%s</ b> a continuación, haga click en el enlace de abajo y compre el producto que desea y use el Certificado. Introduzca el código del Recibo del Certificado en la página del carrito de compra antes de hacer click en Pagar.';
$_['text_footer']   = 'Por Favor responda este E-Mail si tiene preguntas.';
?>