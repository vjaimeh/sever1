<?php
// Heading
$_['heading_title'] = 'Página Requerida No Encontrada!';

// Text
$_['text_error']    = 'Página Requerida No Encontrada.';
?>