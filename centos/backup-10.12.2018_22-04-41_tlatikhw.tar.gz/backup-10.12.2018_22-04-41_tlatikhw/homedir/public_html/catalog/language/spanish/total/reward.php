<?php
// Text
$_['text_reward']   = 'Puntos Descuento(%s)';
$_['text_order_id'] = 'Pedido ID: #%s';
?>