<?php
// Heading 
$_['heading_title'] = 'Escoja una Tienda';

// Text
$_['text_default']  = 'Predeterminada';
$_['text_store']    = 'Por Favor escoja la Tienda que desea Visitar.';
?>