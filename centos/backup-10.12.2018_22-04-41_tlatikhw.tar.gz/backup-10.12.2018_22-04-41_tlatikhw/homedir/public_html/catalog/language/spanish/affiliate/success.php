<?php
// Heading
$_['heading_title'] = 'Su Cuenta de Afiliado ha sido Creada!';

// Text
$_['text_approval'] = '<p>Gracias por registrarse en una cuenta de afiliado con %s!</p><p>Se le notificará por correo electrónico una vez que su cuenta haya sido Activada por nuestro Servicio al Cliente.</p><p>Si usted tiene alguna pregunta sobre el funcionamiento de este sistema de afiliados, por favor <a href="%s">contacte a nuestro Servicio al Cliente</a>.</p>';
$_['text_account']  = 'Cuenta';
$_['text_success']  = 'Correcto';
?>