<?php
// Text
$_['text_subject']  = '%s - Programa de Afiliado';
$_['text_welcome']  = 'Gracias por Unirse al Programa de Afiliado de %s!';
$_['text_approval'] = 'Su Cuenta debe ser Aprobada antes de Conectarse. Una vez Aprobada puede Conectarse usando su Dirección E-Mail y Clave para visitar nuestro Sitio Web o en la siguiente Dirección Web:';
$_['text_services'] = 'Una vez Conectado, Usted tiene la disponibilidad para Generar Códigos de Seguimiento, seguimiento de Pagos por Comisión y editar Información de su Cuenta.';
$_['text_thanks']   = 'Gracias,';
?>