<?php
// Text
$_['text_home']     = 'Inicio';
$_['text_wishlist'] = 'Lista Deseos (%s)';
$_['text_shopping_cart']  = 'Carro de Compras';
$_['text_items']    = '%s item(s) - %s';
$_['text_search']   = 'Búsqueda';
$_['text_welcome']  = 'Bienvenido Visitante <a href="%s">Conectarse</a> o <a href="%s">Crear Cuenta</a>.';
$_['text_logged']   = 'Esta Conectado como <a href="%s">%s</a> <b>(</b> <a href="%s">Desconectar</a> <b>)</b>';
$_['text_account']  = 'Mi Cuenta';
$_['text_checkout'] = 'Pagar';
?>