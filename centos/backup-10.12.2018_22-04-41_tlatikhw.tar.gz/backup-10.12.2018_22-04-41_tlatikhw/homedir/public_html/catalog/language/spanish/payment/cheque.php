<?php
// Text
$_['text_title']       = 'Instrucciones de Cheque / Money Order';
$_['text_instruction'] = 'Cheque / Money Order';
$_['text_payable']     = 'Hacer Pagable A: ';
$_['text_address']     = 'Enviar A: ';
$_['text_payment']     = 'Su Orden NO será Enviada hasta que su PAGO SEA RECIBIDO.';
?>