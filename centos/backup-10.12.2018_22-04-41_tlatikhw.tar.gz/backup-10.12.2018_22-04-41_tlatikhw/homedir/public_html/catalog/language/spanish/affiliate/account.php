<?php
// Heading 
$_['heading_title']        = 'Mi Cuenta de Afiliado';

// Text
$_['text_account']         = 'Cuenta';
$_['text_my_account']      = 'Mi Cuenta de Afiliado';
$_['text_my_tracking']     = 'Mi información de seguimiento';
$_['text_my_transactions'] = 'Mis Transacciones';
$_['text_edit']            = 'Editar información de su cuenta';
$_['text_password']        = 'Cambie su Clave';
$_['text_payment']         = 'Cambie sus preferencias de Pago';
$_['text_tracking']        = 'Código de seguimiento personalizado del Afiliado';
$_['text_transaction']     = 'Ver su historial de Transacciones';
?>