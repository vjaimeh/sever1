<?php
// Text
$_['text_subject']  = '%s - Nueva Clave';
$_['text_greeting'] = 'Una Nueva Clave ha sido solicitada por %s.';
$_['text_password'] = 'Su nueva clave es:';
?>