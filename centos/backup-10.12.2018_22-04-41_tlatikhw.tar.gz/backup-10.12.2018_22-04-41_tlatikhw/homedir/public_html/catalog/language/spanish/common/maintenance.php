<?php
// Heading
$_['heading_title']     = 'Mantenimiento';

// Text
$_['text_maintenance']  = 'Mantenimiento';
$_['text_message']      = '<h1 style="text-align:center;">Actualmente estamos realizando operaciones de mantenimiento. <br/>La tienda se re-activará tan pronto sea posible</h1>';
?>