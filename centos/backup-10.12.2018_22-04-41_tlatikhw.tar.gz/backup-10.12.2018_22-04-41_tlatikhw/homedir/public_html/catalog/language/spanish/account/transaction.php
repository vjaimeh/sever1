<?php
// Heading 
$_['heading_title']      = 'Sus Transacciones';

// Column
$_['column_date_added']  = 'Fecha Adicionada';
$_['column_description'] = 'Descripción';
$_['column_amount']      = 'Monto (%s)';

// Text
$_['text_account']       = 'Cuenta';
$_['text_transaction']   = 'Sus Transacciones';
$_['text_total']         = 'Su Balance actual es:';
$_['text_empty']         = 'Usted no tiene Transacciones!';
?>