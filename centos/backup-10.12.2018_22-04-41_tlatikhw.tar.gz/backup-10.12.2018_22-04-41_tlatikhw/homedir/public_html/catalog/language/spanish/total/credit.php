<?php
$_['text_credit']   = 'Crédito:';
$_['text_order_id'] = 'ID Orden: #%s';
?>