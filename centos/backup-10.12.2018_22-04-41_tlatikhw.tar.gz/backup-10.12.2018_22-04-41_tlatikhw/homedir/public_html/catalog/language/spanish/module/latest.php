<?php
// Heading 
$_['heading_title'] = 'Novedades';

// Text
$_['text_reviews']  = 'Basado en %s comentarios.';
?>