<?php
// Heading
$_['heading_title']    = 'Mapa del Sitio';

// Text
$_['text_special']     = 'Ofertas Especiales';
$_['text_account']     = 'Mi Cuenta';
$_['text_edit']        = 'Información de Cuenta';
$_['text_password']    = 'Clave';
$_['text_address']     = 'Libro Direcciones';
$_['text_history']     = 'Historial de Ordenes';
$_['text_download']    = 'Descargas';
$_['text_cart']        = 'Carro de Compras';
$_['text_checkout']    = 'Pagar';
$_['text_search']      = 'Búsqueda';
$_['text_information'] = 'Información';
$_['text_contact']     = 'Contáctenos';
?>
