<?php
// Heading 
$_['heading_title'] = 'Desconexión de la Cuenta';

// Text
$_['text_message']  = '<p>Usted ha sido Desconectado de su Cuenta. Ahora puede dejar su Computadora.</p><p>Su Carro de Compras ha sido Guardado, los artículos dentro de su Carro serán restaurados cuando Usted se Conecte de nuevo a su Cuenta.</p>';
$_['text_account']  = 'Cuenta';
$_['text_logout']   = 'Desconectar';
?>