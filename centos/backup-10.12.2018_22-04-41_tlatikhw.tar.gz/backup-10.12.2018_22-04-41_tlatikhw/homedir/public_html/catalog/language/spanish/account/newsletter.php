<?php
// Heading 
$_['heading_title']    = 'Subscripción al Boletín Electrónico';

// Text
$_['text_account']     = 'Cuenta';
$_['text_newsletter']  = 'Boletín Electrónico';
$_['text_success']     = 'Correcto: Su Subscripción al Boletín ha sido Satisfactoriamente Actualizada!';

// Entry
$_['entry_newsletter'] = 'Subscribir:';
?>