<?php
// Text
$_['text_title']       = 'Recoger';
$_['text_description'] = 'Recoger en la Empresa';
?>