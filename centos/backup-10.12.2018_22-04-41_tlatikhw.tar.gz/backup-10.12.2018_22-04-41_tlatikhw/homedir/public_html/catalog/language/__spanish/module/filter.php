<?php
// Heading
$_['heading_title']       = 'Filtros'; 

// Text
$_['text_module']         = 'Modulos';
$_['text_success']        = 'Exito: Has modificado el filtro!';
$_['text_content_top']    = 'Content Top';
$_['text_content_bottom'] = 'Content Bottom';
$_['text_column_left']    = 'Column Left';
$_['text_column_right']   = 'Column Right';

// Entry
$_['entry_layout']        = 'Layout:';
$_['entry_position']      = 'Posici�n:';
$_['entry_status']        = 'Estado:';
$_['entry_sort_order']    = 'Orden:';

// Error
$_['error_permission']    = 'Atenci�n: no tienes permisos para modificar el modulo de filtros!';
?>