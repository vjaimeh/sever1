<?php
// Heading
$_['heading_title']    = 'Recoger en Tienda';

// Text
$_['text_shipping']    = 'Envío';
$_['text_success']     = 'Correcto: Ha Modificado el envío Recoger en Tienda!';

// Entry
$_['entry_geo_zone']   = 'Zona Geográfica:';
$_['entry_status']     = 'Estado:';
$_['entry_sort_order'] = 'Orden:';

// Error
$_['error_permission'] = 'Advertencia: No tiene Permiso para Modificar Recoger en Tienda!';
?>