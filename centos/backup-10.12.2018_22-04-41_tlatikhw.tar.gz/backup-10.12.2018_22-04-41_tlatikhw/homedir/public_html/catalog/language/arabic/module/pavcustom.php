<?php
$_['heading_title'] = 'مرحبا بكم في %s';

?>