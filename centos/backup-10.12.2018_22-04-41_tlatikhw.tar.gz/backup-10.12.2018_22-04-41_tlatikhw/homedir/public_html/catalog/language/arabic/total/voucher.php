<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading 
$_['heading_title'] = 'استخدم قسيمة الهدايا';

// Text
$_['text_voucher']  = 'قيمة الهدايا(%s)';
$_['text_success']  = 'تم قبول العملية !';

// Entry
$_['entry_voucher'] = 'ادخل شفرة قسيمة الهدايا هنا:';

// Error
$_['error_voucher'] = 'تحذير: إما أن شفرة قسيمة الهدايا خطأ أو تم استخدام رصيد القسيمة مسبقاً !';
?>