<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading 
$_['heading_title'] = 'استخدم نقاط المكافآت (المتاح %s)';

// Text
$_['text_reward']   = 'نقاط المكافآت (%s)';
$_['text_order_id'] = 'رقم الطلب : #%s';
$_['text_success']  = 'تم قبول نقاط المكافآت !';

// Entry
$_['entry_reward']  = 'النقاط المسموح بها للاستخدم (الحد الأقصى %s):';

// Error
$_['error_empty']   = 'تحذير: الرجاء إدخال عدد النقاط المطلوبة للاستخدام !';
$_['error_points']  = 'تحذير: لا يوجد لديك %s نقاط مكافآت !';
$_['error_maximum'] = 'تحذير: عدد النقاط الأقصى المسموح به هو %s!';
?>