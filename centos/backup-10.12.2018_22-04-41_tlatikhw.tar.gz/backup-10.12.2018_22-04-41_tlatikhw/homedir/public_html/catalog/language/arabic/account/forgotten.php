<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading 
$_['heading_title']   = 'هل نسيت كلمة المرور؟';

// Text
$_['text_account']    = 'الحساب';
$_['text_forgotten']  = 'استعادة كلمة المرور';
$_['text_your_email'] = 'البريد الالكتروني';
$_['text_email']      = 'أدخل البريد الالكتروني المرتبط مع حسابك. انقر على متابعه ليتم إرسال كلمة المرور إلى بريدك الخاص';
$_['text_success']    = 'تم إرسال كلمة مرور جديدة إلى بريدك الإلكتروني.';

// Entry
$_['entry_email']     = 'البريد الإلكتروني:';

// Error
$_['error_email']     = 'تحذير : البريد الإلكتروني لم يتم العثور علية في سجلاتنا ، يرجى المحاولة مرة أخرى!';
?>