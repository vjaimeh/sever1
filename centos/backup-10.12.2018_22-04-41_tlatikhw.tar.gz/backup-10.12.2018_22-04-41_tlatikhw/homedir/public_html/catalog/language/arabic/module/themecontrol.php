<?php 
$_['text_my_menu'] = 'القائمة بلدي';

?>