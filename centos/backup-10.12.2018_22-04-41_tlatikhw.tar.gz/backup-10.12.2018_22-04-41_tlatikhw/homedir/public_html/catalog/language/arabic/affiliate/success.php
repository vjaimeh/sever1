<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title'] = 'تم إنشاء حسابك في برنامج أفليت!';

// Text 
$_['text_approval'] = '<p>شكراً لتسجيلك في برنامج أفليت في %s!</p><p>سوف يتم إرسال اشعار إلى بريدك الالكتروني لتفعيل حسابك.</p><p>اذا كان لديك أي استفسارات بخصوص برنامج أفليت معنا, الرجاء <a href="%s">الاتصال بنا</a>.</p>';
$_['text_account']  = 'الحساب';
$_['text_success']  = 'نجاح';
?>