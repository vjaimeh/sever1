<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_title']  = 'United States Postal Service';
$_['text_weight'] = 'Weight:';
$_['text_eta']    = 'Estimated Time:';
?>