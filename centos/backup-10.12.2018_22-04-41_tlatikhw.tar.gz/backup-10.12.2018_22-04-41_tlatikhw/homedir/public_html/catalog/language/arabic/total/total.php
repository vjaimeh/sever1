<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

$_['text_total'] = 'الاجمالي النهائي';
?>