<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading 
$_['heading_title']        = 'حسابي في أفليت';

// Text
$_['text_account']         = 'الحساب';
$_['text_my_account']      = 'حسابي في أفليت';
$_['text_my_tracking']     = 'تتبع معلوماتي';
$_['text_my_transactions'] = 'عمليات حسابي';
$_['text_edit']            = 'تحير معلومات حسابك';
$_['text_password']        = 'تغيير كلمة المرور';
$_['text_payment']         = 'تغيير طريقة الدفع المفضلة لك';
$_['text_tracking']        = 'تخصيص كود تتبع';
$_['text_transaction']     = 'عرض تاريخ عمليات حسابك';
?>