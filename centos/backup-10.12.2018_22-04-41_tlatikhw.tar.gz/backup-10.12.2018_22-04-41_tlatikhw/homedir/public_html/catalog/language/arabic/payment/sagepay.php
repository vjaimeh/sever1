<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_title']       = 'Credit Card / Debit Card (SagePay)';
$_['text_description'] = 'Items on %s Order No: %s';
?>