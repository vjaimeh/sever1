<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading 
$_['heading_title'] = 'قسيمة التخفيض';

// Text
$_['text_coupon']  = 'القسيمة(%s)';
$_['text_success'] = 'نجاح: تم الموافقة على قسيمة التخفيض !';

// Entry
$_['entry_coupon'] = 'أدخل رمز التخفيض الخاص بك :';

// Error
$_['error_coupon'] = 'تحذير: قسيمة التخفيض غير صالحة أو انتهت أو تم استخدام الحد المسموح به !';
?>