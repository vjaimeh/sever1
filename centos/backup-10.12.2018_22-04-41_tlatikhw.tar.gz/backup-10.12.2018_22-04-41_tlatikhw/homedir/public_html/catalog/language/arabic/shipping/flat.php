<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_title']       = 'Flat Rate';
$_['text_description'] = 'Flat Shipping Rate';
?>