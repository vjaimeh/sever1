<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading 
$_['heading_title']   = 'حساب التنزيل';

// Text
$_['text_account']    = 'الحساب';
$_['text_downloads']  = 'التنزيلات';
$_['text_order']      = 'رقم الطلب:';
$_['text_date_added'] = 'تاريخ الاضافة:';
$_['text_name']       = 'الاسم:';
$_['text_remaining']  = 'المتبقي:';
$_['text_size']       = 'الحجم:';
$_['text_download']   = 'تنزيل';
$_['text_empty']      = 'لم تقم بطلب أي خدمة للتنزيل حتى الآن!';
?>