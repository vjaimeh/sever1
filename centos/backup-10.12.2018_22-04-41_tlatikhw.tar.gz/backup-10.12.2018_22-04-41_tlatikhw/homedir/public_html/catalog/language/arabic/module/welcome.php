<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

$_['heading_title'] = 'مرحباً بك في %s';
?>