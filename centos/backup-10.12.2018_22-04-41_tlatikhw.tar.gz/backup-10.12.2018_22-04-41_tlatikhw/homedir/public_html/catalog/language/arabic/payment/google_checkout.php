<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Entry
$_['entry_postcode'] = 'Post Code:';
$_['entry_country']  = 'Country:';
$_['entry_zone']     = 'Region / State:';
?>