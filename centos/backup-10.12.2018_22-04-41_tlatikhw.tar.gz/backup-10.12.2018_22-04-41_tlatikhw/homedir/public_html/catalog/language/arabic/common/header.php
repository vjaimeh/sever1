<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_home']      = 'الرئيسية';
$_['text_wishlist']  = 'قائمة رغباتي (%s)';
$_['text_cart']      = 'سلة الشراء';
$_['text_items']     = '%s منتجات - %s';
$_['text_shopping_cart']      = 'سلة الشراء';
$_['text_search']    = 'بحث';
$_['text_welcome']   = 'مرحبا بالزائر، يمكنك <a href="%s">تسجيل الدخول</a> أو <a href="%s">تسجيل جديد</a>.';
$_['text_logged']    = 'لقد قمت بتسجيل الدخول بإسم <a href="%s">%s</a> <b>(</b> <a href="%s">خروج</a> <b>)</b>';
$_['text_account']   = 'حسابي';
$_['text_checkout']  = 'إنهاء الطلب';
$_['text_language'] = 'اللغة';
$_['text_currency'] = 'العملة';
?>