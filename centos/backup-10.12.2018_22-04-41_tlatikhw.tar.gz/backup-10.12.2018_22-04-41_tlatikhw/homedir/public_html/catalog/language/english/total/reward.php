<?php
// Text
$_['text_reward']   = 'Reward Points(%s)';
$_['text_order_id'] = 'Order ID: #%s';
?>