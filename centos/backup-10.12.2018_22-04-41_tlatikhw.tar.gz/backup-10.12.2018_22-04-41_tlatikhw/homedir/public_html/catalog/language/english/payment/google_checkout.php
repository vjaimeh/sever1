<?php
// Entry
$_['text_title']     = 'Credit Card / Debit Card (Google Checkout)';

// Error
$_['error_shipping'] = 'Warning: Shipping method required!';
?>