<?php 

$_['text_sale'] = 'Sale';
$_['text_new'] = 'New';
$_['text_sale_detail'] = 'Save: %s';
$_['text_contact_us'] = 'Contact Us';

$_['text_color_tools'] = 'Live Theme Editor';
$_['text_selectors']   = 'Layout Selectors';
$_['text_elements']   = 'Layout Elements';


$_['text_sidebar_left'] = 'Sidebar Left';
$_['text_sidebar_right'] = 'Sidebar Right';

$_['text_about_us'] = 'About Us';
$_['quick_view'] = 'Quick View';
$_['text_blogs'] = 'Blog';
$_['entry_sign_up'] = "Sign Up";
?>